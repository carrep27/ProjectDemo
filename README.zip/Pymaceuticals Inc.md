

```python
#Import Dependencies
import random
import matplotlib.pyplot as plt
import numpy as np
from statistics import mean, median, mode
import pandas as pd
```


```python
#Read Data
clinical_trial_data = pd.read_csv("clinicaltrial_data.csv")
mouse_drug_data = pd.read_csv("mouse_drug_data.csv")

#merge clinical and drug data on mouse id

combined = pd.merge(clinical_trial_data, mouse_drug_data, on="Mouse ID", how="outer")

```


```python
#filter for drug Capomulin
Cap = combined.loc[combined["Drug"]=="Capomulin"]
#get time points which will be our X-axis
Timepoints = Cap.groupby("Timepoint")
Timepoints.mean()

    
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
      <td>0.652174</td>
    </tr>
    <tr>
      <th>25</th>
      <td>39.939528</td>
      <td>0.818182</td>
    </tr>
    <tr>
      <th>30</th>
      <td>38.769339</td>
      <td>1.090909</td>
    </tr>
    <tr>
      <th>35</th>
      <td>37.816839</td>
      <td>1.181818</td>
    </tr>
    <tr>
      <th>40</th>
      <td>36.958001</td>
      <td>1.380952</td>
    </tr>
    <tr>
      <th>45</th>
      <td>36.236114</td>
      <td>1.476190</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create list for X-Value and Y-Values using for loops

XCap = []
YCap = []

for Timepoint, Vol in Timepoints:
    XCap.append(Timepoint)
    YCap.append(Vol["Tumor Volume (mm3)"].mean())
    
#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XCap, YCap, np.std(YCap),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Tumor Volume")
ax.set_title("Capomulin")
plt.show()
```


![png](output_3_0.png)



```python
#filter for drug Ketapril
Ket = combined.loc[combined["Drug"]=="Ketapril"]
#get time points which will be our X-axis
TimepointsK = Ket.groupby("Timepoint")
TimepointsK.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>47.389175</td>
      <td>0.304348</td>
    </tr>
    <tr>
      <th>10</th>
      <td>49.582269</td>
      <td>0.590909</td>
    </tr>
    <tr>
      <th>15</th>
      <td>52.399974</td>
      <td>0.842105</td>
    </tr>
    <tr>
      <th>20</th>
      <td>54.920935</td>
      <td>1.210526</td>
    </tr>
    <tr>
      <th>25</th>
      <td>57.678982</td>
      <td>1.631579</td>
    </tr>
    <tr>
      <th>30</th>
      <td>60.994507</td>
      <td>2.055556</td>
    </tr>
    <tr>
      <th>35</th>
      <td>63.371686</td>
      <td>2.294118</td>
    </tr>
    <tr>
      <th>40</th>
      <td>66.068580</td>
      <td>2.733333</td>
    </tr>
    <tr>
      <th>45</th>
      <td>70.662958</td>
      <td>3.363636</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create list for X-Value and Y-Values using for loops

XKet = []
YKet = []
for Timepoint, Vol in TimepointsK:
    XKet.append(Timepoint)
    YKet.append(Vol["Tumor Volume (mm3)"].mean())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XKet, YKet, np.std(YKet),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Tumor Volume")
ax.set_title("Ketapril")
plt.show()
```


![png](output_5_0.png)



```python
#filter for drug Infubinol
Inf = combined.loc[combined["Drug"]=="Infubinol"]
#get time points which will be our X-axis
TimepointsI = Inf.groupby("Timepoint")
TimepointsI.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>47.062001</td>
      <td>0.280000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>49.403909</td>
      <td>0.666667</td>
    </tr>
    <tr>
      <th>15</th>
      <td>51.296397</td>
      <td>0.904762</td>
    </tr>
    <tr>
      <th>20</th>
      <td>53.197691</td>
      <td>1.050000</td>
    </tr>
    <tr>
      <th>25</th>
      <td>55.715252</td>
      <td>1.277778</td>
    </tr>
    <tr>
      <th>30</th>
      <td>58.299397</td>
      <td>1.588235</td>
    </tr>
    <tr>
      <th>35</th>
      <td>60.742461</td>
      <td>1.666667</td>
    </tr>
    <tr>
      <th>40</th>
      <td>63.162824</td>
      <td>2.100000</td>
    </tr>
    <tr>
      <th>45</th>
      <td>65.755562</td>
      <td>2.111111</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create list for X-Value and Y-Values using for loops

XInf = []
YInf = []
for Timepoint, Vol in TimepointsI:
    XInf.append(Timepoint)
    YInf.append(Vol["Tumor Volume (mm3)"].mean())

# create scatter plot
fig, ax = plt.subplots()
ax.errorbar(XInf, YInf, np.std(YInf),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Tumor Volume")
ax.set_title("Infubinol")
plt.show()
```


![png](output_7_0.png)



```python
#filter for drug Placebo
Pbo = combined.loc[combined["Drug"]=="Placebo"]
#get time points which will be our X-axis
TimepointsP = Pbo.groupby("Timepoint")
TimepointsP.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>47.125589</td>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>49.423329</td>
      <td>0.833333</td>
    </tr>
    <tr>
      <th>15</th>
      <td>51.359742</td>
      <td>1.250000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>54.364417</td>
      <td>1.526316</td>
    </tr>
    <tr>
      <th>25</th>
      <td>57.482574</td>
      <td>1.941176</td>
    </tr>
    <tr>
      <th>30</th>
      <td>59.809063</td>
      <td>2.266667</td>
    </tr>
    <tr>
      <th>35</th>
      <td>62.420615</td>
      <td>2.642857</td>
    </tr>
    <tr>
      <th>40</th>
      <td>65.052675</td>
      <td>3.166667</td>
    </tr>
    <tr>
      <th>45</th>
      <td>68.084082</td>
      <td>3.272727</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create list for X-Value and Y-Values using for loops

XPbo = []
YPbo = []
for Timepoint, Vol in TimepointsP:
    XPbo.append(Timepoint)
    YPbo.append(Vol["Tumor Volume (mm3)"].mean())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XPbo, YPbo, np.std(YPbo),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Tumor Volume")
ax.set_title("Placebo")
plt.show()
```


![png](output_9_0.png)



```python
#combine all graphs onto one
fig, ax = plt.subplots()
ax.errorbar(XCap, YCap, np.std(YCap),fmt="o",color="limegreen")
ax.errorbar(XKet, YKet, np.std(YKet),fmt="o",color="red")
ax.errorbar(XInf, YInf, np.std(YInf),fmt="o",color="blue")
ax.errorbar(XPbo, YPbo, np.std(YPbo),fmt="o",color="purple")
ax.set_xlabel("Time")
ax.set_ylabel("Tumor Volume")
ax.set_title("Drug Efficacy Over Time")
plt.legend(labels=["Capomulin","Ketapril","Infubinol","Placebo"],loc="best")
plt.show()
```


![png](output_10_0.png)



```python
#same process as above but Metastatic Sites avergae is used instead of Tumor Volume

#filter for drug Capomulin
Cap = combined.loc[combined["Drug"]=="Capomulin"]
#get time points which will be our X-axis
TimepointsC = Cap.groupby("Timepoint")
TimepointsC.mean()

#create list for X-Value and Y-Values using for loops

XCap = []
YCap2 = []

for Timepoint, Sites in TimepointsC:
    XCap.append(Timepoint)
    YCap2.append(Sites["Metastatic Sites"].mean())
    
#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XCap, YCap2, np.std(YCap2),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Metastatic Sites")
ax.set_title("Capomulin")
plt.show()

#filter for drug Ketapril
Ket = combined.loc[combined["Drug"]=="Ketapril"]
#get time points which will be our X-axis
TimepointsK = Ket.groupby("Timepoint")
TimepointsK.mean()

#create list for X-Value and Y-Values using for loops

XKet = []
YKet2 = []
for Timepoint, Sites in TimepointsK:
    XKet.append(Timepoint)
    YKet2.append(Sites["Metastatic Sites"].mean())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XKet, YKet2, np.std(YKet2),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Metastatic Sites")
ax.set_title("Ketapril")
plt.show()

#filter for drug Infubinol
Inf = combined.loc[combined["Drug"]=="Infubinol"]
#get time points which will be our X-axis
TimepointsI = Inf.groupby("Timepoint")
TimepointsI.mean()
#create list for X-Value and Y-Values using for loops

XInf = []
YInf2 = []
for Timepoint, Sites in TimepointsI:
    XInf.append(Timepoint)
    YInf2.append(Sites["Metastatic Sites"].mean())

# create scatter plot
fig, ax = plt.subplots()
ax.errorbar(XInf, YInf2, np.std(YInf2),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Metastatic Sites")
ax.set_title("Infubinol")
plt.show()

#filter for drug Placebo
Pbo = combined.loc[combined["Drug"]=="Placebo"]
#get time points which will be our X-axis
TimepointsP = Pbo.groupby("Timepoint")
TimepointsP.mean()
#create list for X-Value and Y-Values using for loops

XPbo = []
YPbo2 = []
for Timepoint, Sites in TimepointsP:
    XPbo.append(Timepoint)
    YPbo2.append(Sites["Metastatic Sites"].mean())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XPbo, YPbo2, np.std(YPbo2),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Metastatic Sites")
ax.set_title("Placebo")
plt.show()
#combine all graphs onto one
fig, ax = plt.subplots()
ax.errorbar(XCap, YCap2, np.std(YCap2),fmt="o",color="limegreen")
ax.errorbar(XKet, YKet2, np.std(YKet2),fmt="o",color="red")
ax.errorbar(XInf, YInf2, np.std(YInf2),fmt="o",color="blue")
ax.errorbar(XPbo, YPbo2, np.std(YPbo2),fmt="o",color="purple")
ax.set_xlabel("Time")
ax.set_ylabel("Metastatic Sites")
ax.set_title("Metastatic Sites Over Time")
plt.legend(labels=["Capomulin","Ketapril","Infubinol","Placebo"],loc="best")
plt.show()

```


![png](output_11_0.png)



![png](output_11_1.png)



![png](output_11_2.png)



![png](output_11_3.png)



![png](output_11_4.png)



```python
#same process as above but using Mouse ID Count in order to get mouse mortatilty rate

#filter for drug Capomulin
Cap = combined.loc[combined["Drug"]=="Capomulin"]
#get time points which will be our X-axis
TimepointsC = Cap.groupby("Timepoint")
TimepointsC.mean()

#create list for X-Value and Y-Values using for loops

XCap = []
YCap3 = []

for Timepoint, Mouse in TimepointsC:
    XCap.append(Timepoint)
    YCap3.append(Mouse["Mouse ID"].count())
    
#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XCap, YCap3, np.std(YCap3),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Mice")
ax.set_title("Capomulin")
plt.show()

#filter for drug Ketapril
Ket = combined.loc[combined["Drug"]=="Ketapril"]
#get time points which will be our X-axis
TimepointsK = Ket.groupby("Timepoint")
TimepointsK.mean()

#create list for X-Value and Y-Values using for loops

XKet = []
YKet3 = []
for Timepoint, Mouse in TimepointsK:
    XKet.append(Timepoint)
    YKet3.append(Mouse["Mouse ID"].count())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XKet, YKet3, np.std(YKet3),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Mice")
ax.set_title("Ketapril")
plt.show()

#filter for drug Infubinol
Inf = combined.loc[combined["Drug"]=="Infubinol"]
#get time points which will be our X-axis
TimepointsI = Inf.groupby("Timepoint")
TimepointsI.mean()
#create list for X-Value and Y-Values using for loops

XInf = []
YInf3 = []
for Timepoint, Sites in TimepointsI:
    XInf.append(Timepoint)
    YInf3.append(Sites["Mouse ID"].count())

# create scatter plot
fig, ax = plt.subplots()
ax.errorbar(XInf, YInf3, np.std(YInf3),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Mice")
ax.set_title("Infubinol")
plt.show()

#filter for drug Placebo
Pbo = combined.loc[combined["Drug"]=="Placebo"]
#get time points which will be our X-axis
TimepointsP = Pbo.groupby("Timepoint")
TimepointsP.mean()
#create list for X-Value and Y-Values using for loops

XPbo = []
YPbo3 = []
for Timepoint, Sites in TimepointsP:
    XPbo.append(Timepoint)
    YPbo3.append(Sites["Mouse ID"].count())

#create scatter plot

fig, ax = plt.subplots()
ax.errorbar(XPbo, YPbo3, np.std(YPbo3),fmt="o")
ax.set_xlabel("Time")
ax.set_ylabel("Mice")
ax.set_title("Placebo")
plt.show()
#combine all graphs onto one
fig, ax = plt.subplots()
ax.errorbar(XCap, YCap3, np.std(YCap3),fmt="o",color="limegreen")
ax.errorbar(XKet, YKet3, np.std(YKet3),fmt="o",color="red")
ax.errorbar(XInf, YInf3, np.std(YInf3),fmt="o",color="blue")
ax.errorbar(XPbo, YPbo3, np.std(YPbo3),fmt="o",color="purple")
ax.set_xlabel("Time")
ax.set_ylabel("Mouse Count")
ax.set_title("Living Mouse Count Over Time")
plt.legend(labels=["Capomulin","Ketapril","Infubinol","Placebo"],loc="best")
plt.show()
```


![png](output_12_0.png)



![png](output_12_1.png)



![png](output_12_2.png)



![png](output_12_3.png)



![png](output_12_4.png)



```python
#get % change growth using formula (new-original)/original. 
#original value assumed to be 0.01

capperchange = (YCap2[-1]-0.01)/(0.01)
ketperchange = (YKet2[-1]-0.01)/0.01
infperchange = (YInf2[-1]-0.01)/0.01
pboperchange = (YPbo2[-1]-0.01)/0.01

#create bar chart showing % growth change

drugs = ["Capomulin","Ketapril","Infubinol","Placebo"]
xvalues = ["Capomulin","Ketapril","Infubinol","Placebo"]
yvalues = (capperchange,ketperchange,infperchange,pboperchange)           

fig, ax = plt.subplots()
index = xvalues
bar_width= 0.35
opacity = 0.4
rects1 = ax.bar(index, yvalues, bar_width, alpha = 0.4, color="b")

ax.set_xlabel("Drug")
ax.set_ylabel("% Growth")
ax.set_title("Metastic Site Growth Over Time (inital growth assumed at 0.01)")
ax.set_xticks(index)
ax.set_xticklabels(drugs)
fig.tight_layout()
plt.show()


```


![png](output_13_0.png)


Observations
Capomulin had the greatest affect on tumor growth (indicated by fewer metatstatic sites versus Placebo) 
Capolmulin kept the most mice alive and showed the least amount of tumorw growth.
Ketapril showed greater metastatic growth than the placebo trials. 
Second best drug would appear to be Infubinol althouhg that drug had the greatest mortality rate. 

